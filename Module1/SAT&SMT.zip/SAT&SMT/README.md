To run the SAT and SMT solvers go into the files called PWP_SAT.py or PWP_SMT.py respectively in the src-folder and run them. This will then fill the folders src/SAT_Solutions and src/SMT_Solutions with both the solutions in written format and a figure illustrating how the presents are placed. The solution folder are empty when I'm delivering, but will fill up with solutions if you test the code. You can find my solutions in the out-folder. 

The util.py code contains all my utility functions for both the SAT and SMT solver.
